package com.originos.studio;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Hosts index.html in a WebView and exposes the real system wallpaper to it. */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 7;
    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.addJavascriptInterface(new Bridge(), "WallpaperBridge");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    private Bitmap decode(String dataUrl) {
        byte[] b = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(b, 0, b.length);
    }

    private void toJs(boolean ok, String message) {
        runOnUiThread(() -> web.evaluateJavascript(
                "window.onNative(" + ok + "," + JSONObject.quote(message) + ")", null));
    }

    /** Methods here are callable from JavaScript as WallpaperBridge.xxx(). */
    private class Bridge {

        /** target: 0 = home screen, 1 = lock screen, 2 = both. */
        @JavascriptInterface
        public void setWallpaper(final String dataUrl, final int target) {
            new Thread(() -> {
                try {
                    Bitmap bmp = decode(dataUrl);
                    int flags = target == 0 ? WallpaperManager.FLAG_SYSTEM
                            : target == 1 ? WallpaperManager.FLAG_LOCK
                            : (WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
                    WallpaperManager.getInstance(MainActivity.this).setBitmap(bmp, null, true, flags);
                    toJs(true, "Wallpaper set");
                } catch (Throwable e) {
                    toJs(false, "Could not set wallpaper: " + e.getMessage());
                }
            }).start();
        }

        @JavascriptInterface
        public void savePng(final String dataUrl) {
            new Thread(() -> {
                try {
                    Bitmap bmp = decode(dataUrl);
                    String name = "OriginOSStudio_" + System.currentTimeMillis() + ".png";
                    OutputStream out;
                    String where;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OriginOSStudio");
                        Uri u = getContentResolver().insert(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                        out = getContentResolver().openOutputStream(u);
                        where = "Pictures/OriginOSStudio";
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                        File f = new File(dir, name);
                        out = new FileOutputStream(f);
                        where = f.getAbsolutePath();
                    }
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                    out.close();
                    toJs(true, "Saved to " + where);
                } catch (Throwable e) {
                    toJs(false, "Could not save: " + e.getMessage());
                }
            }).start();
        }
    }
}
