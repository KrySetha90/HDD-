OriginOS Studio
===============

index.html  (zip root)
  The whole editor in one file. Open it in Chrome, or feed it to an
  HTML-to-APK app. Without the Android host it can save PNG files but
  cannot change the phone wallpaper.

app/ + gradle files + .github/workflows/main.yml
  A small Android app that shows the same index.html in a WebView and adds
  two real functions: set the phone wallpaper (home / lock / both) and save
  PNG to the gallery. Push this whole folder to GitHub; the workflow builds
  app-debug.apk. app/src/main/assets/index.html is the copy the app uses.
  If you edit index.html, copy it over that file too.

How to use
  1. Upload a picture.
  2. Draw, then circle an area. "Wobble area" jiggles with shake or tilt.
     "Depth cut-out" puts that shape in front of the clock.
  3. Pick a theme, adjust the clock with Clock options.
  4. Set wallpaper. The image is saved with the current frame.
